﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 1");
        Console.WriteLine("Ingrese un número entero");
        string numString = Console.ReadLine();
        int n1 = 0;
        bool canConvert = int.TryParse(numString, out n1);
        if (canConvert == true)
        {
            Console.WriteLine("numero: " + n1);
            if (n1 > 0)
            {
                Console.WriteLine("RESULTADO: Positivo");
            }
            else if (n1 == 0)
            {
                Console.WriteLine("RESULTADO: Número cero");
            }
            else
            {
                Console.WriteLine("RESULTADO : Negativo");
            }
        }
        else
        {
            Console.WriteLine("Usted ingreso una letra");
        }
        Console.WriteLine("");
        Console.WriteLine("Presione una tecla para continuar");
        Console.ReadKey();
        Console.WriteLine("");
        // ejercicio 2
        Console.WriteLine("Ejercicio 2:");
        Console.WriteLine("Siendo Lunes = 1 y Domingo = 7");
        Console.WriteLine("Ingrese un número");
        string numString2 = Console.ReadLine();
        int d = 0;
        bool canConvert2 = int.TryParse(numString2, out d);
        if (canConvert2 == true)
        {
            switch (d)
            {
                case 1:
                    Console.WriteLine("Dia: Lunes");
                    break;
                case 2:
                    Console.WriteLine("Dia: Martes");
                    break;
                case 3:
                    Console.WriteLine("Dia: Miércoles");
                    break;
                case 4:
                    Console.WriteLine("Dia: Jueves");
                    break;
                case 5:
                    Console.WriteLine("Dia: Viernes");
                    break;
                case 6:
                    Console.WriteLine("Dia: Sabado");
                    break;
                case 7:
                    Console.WriteLine("Dia: Domingo");
                    break;
                default:
                    Console.WriteLine("Error: el número a ingresar debe estar contenido entre 1 y 7 ");
                    break;
            }
        }
        else {
            Console.WriteLine("Erro: usten ingreso una letra, no un número");
                }
        
        Console.ReadKey();

    }
}