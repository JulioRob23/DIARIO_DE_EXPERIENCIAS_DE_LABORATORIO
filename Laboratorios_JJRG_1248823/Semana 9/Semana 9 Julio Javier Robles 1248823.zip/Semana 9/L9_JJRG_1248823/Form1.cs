﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L9_JJRG_1248823
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Automovil myAutomovil = new Automovil();

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BTNcambiardispo_Click(object sender, EventArgs e)
        {
            myAutomovil.CambiarDisponibilidad();
            TXTdatosautomovil.Text = myAutomovil.MostrarInformacion();
        }

        private void BTNguardarinfo_Click(object sender, EventArgs e)
        {
            myAutomovil.DefinirModelo(Convert.ToInt32(TXTmodelo.Text));
            myAutomovil.DefinirPrecio(Convert.ToDouble(TXTprecio.Text));
            myAutomovil.DefinirMarca(TXTmarca.Text);
            myAutomovil.DefinirTipoCambio(Convert.ToDouble(TXTtipodecambio.Text));

            MessageBox.Show("Los Datos gueron guardados exitosamente");

            TXTdatosautomovil.Text = myAutomovil.MostrarInformacion();
        }

        private void BTNsalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BTNlimpiar_Click(object sender, EventArgs e)
        {
            TXTmodelo.Clear();
            TXTprecio.Clear();
            TXTmarca.Clear();
            TXTtipodecambio.Clear();
        }

        private void BTNaplicar_Click(object sender, EventArgs e)
        { 
            myAutomovil.AplicarDescuento(Convert.ToDouble(TXTdescuento.Text));
            TXTdatosautomovil.Text = myAutomovil.MostrarInformacion();
        }
    }
}
