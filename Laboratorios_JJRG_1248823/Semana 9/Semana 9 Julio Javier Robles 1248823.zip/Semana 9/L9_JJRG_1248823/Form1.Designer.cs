﻿namespace L9_JJRG_1248823
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TAB = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.BTNguardarinfo = new System.Windows.Forms.Button();
            this.TXTtipodecambio = new System.Windows.Forms.TextBox();
            this.TXTmarca = new System.Windows.Forms.TextBox();
            this.TXTprecio = new System.Windows.Forms.TextBox();
            this.TXTmodelo = new System.Windows.Forms.TextBox();
            this.LBLtipodecambio = new System.Windows.Forms.Label();
            this.LBLmarca = new System.Windows.Forms.Label();
            this.LBLprecio = new System.Windows.Forms.Label();
            this.LBLmodelo = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.TXTdatosautomovil = new System.Windows.Forms.TextBox();
            this.BTNcambiardispo = new System.Windows.Forms.Button();
            this.BTNaplicar = new System.Windows.Forms.Button();
            this.TXTdescuento = new System.Windows.Forms.TextBox();
            this.LBLdescuento = new System.Windows.Forms.Label();
            this.BTNlimpiar = new System.Windows.Forms.Button();
            this.BTNsalir = new System.Windows.Forms.Button();
            this.LBLtitulo = new System.Windows.Forms.Label();
            this.TAB.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // TAB
            // 
            this.TAB.Controls.Add(this.tabPage1);
            this.TAB.Controls.Add(this.tabPage2);
            this.TAB.Location = new System.Drawing.Point(151, 82);
            this.TAB.Name = "TAB";
            this.TAB.SelectedIndex = 0;
            this.TAB.Size = new System.Drawing.Size(478, 343);
            this.TAB.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.BTNguardarinfo);
            this.tabPage1.Controls.Add(this.TXTtipodecambio);
            this.tabPage1.Controls.Add(this.TXTmarca);
            this.tabPage1.Controls.Add(this.TXTprecio);
            this.tabPage1.Controls.Add(this.TXTmodelo);
            this.tabPage1.Controls.Add(this.LBLtipodecambio);
            this.tabPage1.Controls.Add(this.LBLmarca);
            this.tabPage1.Controls.Add(this.LBLprecio);
            this.tabPage1.Controls.Add(this.LBLmodelo);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(470, 310);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Ingreso de Datos";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // BTNguardarinfo
            // 
            this.BTNguardarinfo.Location = new System.Drawing.Point(124, 200);
            this.BTNguardarinfo.Name = "BTNguardarinfo";
            this.BTNguardarinfo.Size = new System.Drawing.Size(141, 72);
            this.BTNguardarinfo.TabIndex = 8;
            this.BTNguardarinfo.Text = "Guardar\r\nInformación\r\n";
            this.BTNguardarinfo.UseVisualStyleBackColor = false;
            this.BTNguardarinfo.Click += new System.EventHandler(this.BTNguardarinfo_Click);
            // 
            // TXTtipodecambio
            // 
            this.TXTtipodecambio.Location = new System.Drawing.Point(189, 151);
            this.TXTtipodecambio.Name = "TXTtipodecambio";
            this.TXTtipodecambio.Size = new System.Drawing.Size(100, 26);
            this.TXTtipodecambio.TabIndex = 7;
            // 
            // TXTmarca
            // 
            this.TXTmarca.Location = new System.Drawing.Point(189, 111);
            this.TXTmarca.Name = "TXTmarca";
            this.TXTmarca.Size = new System.Drawing.Size(100, 26);
            this.TXTmarca.TabIndex = 6;
            // 
            // TXTprecio
            // 
            this.TXTprecio.Location = new System.Drawing.Point(189, 73);
            this.TXTprecio.Name = "TXTprecio";
            this.TXTprecio.Size = new System.Drawing.Size(100, 26);
            this.TXTprecio.TabIndex = 5;
            // 
            // TXTmodelo
            // 
            this.TXTmodelo.Location = new System.Drawing.Point(189, 32);
            this.TXTmodelo.Name = "TXTmodelo";
            this.TXTmodelo.Size = new System.Drawing.Size(100, 26);
            this.TXTmodelo.TabIndex = 4;
            // 
            // LBLtipodecambio
            // 
            this.LBLtipodecambio.AutoSize = true;
            this.LBLtipodecambio.Location = new System.Drawing.Point(35, 154);
            this.LBLtipodecambio.Name = "LBLtipodecambio";
            this.LBLtipodecambio.Size = new System.Drawing.Size(116, 20);
            this.LBLtipodecambio.TabIndex = 3;
            this.LBLtipodecambio.Text = "Tipo de cambio";
            this.LBLtipodecambio.Click += new System.EventHandler(this.label4_Click);
            // 
            // LBLmarca
            // 
            this.LBLmarca.AutoSize = true;
            this.LBLmarca.Location = new System.Drawing.Point(78, 111);
            this.LBLmarca.Name = "LBLmarca";
            this.LBLmarca.Size = new System.Drawing.Size(53, 20);
            this.LBLmarca.TabIndex = 2;
            this.LBLmarca.Text = "Marca";
            this.LBLmarca.Click += new System.EventHandler(this.label3_Click);
            // 
            // LBLprecio
            // 
            this.LBLprecio.AutoSize = true;
            this.LBLprecio.Location = new System.Drawing.Point(78, 73);
            this.LBLprecio.Name = "LBLprecio";
            this.LBLprecio.Size = new System.Drawing.Size(53, 20);
            this.LBLprecio.TabIndex = 1;
            this.LBLprecio.Text = "Precio";
            // 
            // LBLmodelo
            // 
            this.LBLmodelo.AutoSize = true;
            this.LBLmodelo.Location = new System.Drawing.Point(78, 32);
            this.LBLmodelo.Name = "LBLmodelo";
            this.LBLmodelo.Size = new System.Drawing.Size(61, 20);
            this.LBLmodelo.TabIndex = 0;
            this.LBLmodelo.Text = "Modelo";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.TXTdatosautomovil);
            this.tabPage2.Controls.Add(this.BTNcambiardispo);
            this.tabPage2.Controls.Add(this.BTNaplicar);
            this.tabPage2.Controls.Add(this.TXTdescuento);
            this.tabPage2.Controls.Add(this.LBLdescuento);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(470, 310);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Datos Automovil";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // TXTdatosautomovil
            // 
            this.TXTdatosautomovil.Location = new System.Drawing.Point(126, 100);
            this.TXTdatosautomovil.Multiline = true;
            this.TXTdatosautomovil.Name = "TXTdatosautomovil";
            this.TXTdatosautomovil.Size = new System.Drawing.Size(217, 109);
            this.TXTdatosautomovil.TabIndex = 4;
            // 
            // BTNcambiardispo
            // 
            this.BTNcambiardispo.Location = new System.Drawing.Point(169, 231);
            this.BTNcambiardispo.Name = "BTNcambiardispo";
            this.BTNcambiardispo.Size = new System.Drawing.Size(122, 55);
            this.BTNcambiardispo.TabIndex = 3;
            this.BTNcambiardispo.Text = "Cambiar \r\ndisponibilidad\r\n";
            this.BTNcambiardispo.UseVisualStyleBackColor = true;
            this.BTNcambiardispo.Click += new System.EventHandler(this.BTNcambiardispo_Click);
            // 
            // BTNaplicar
            // 
            this.BTNaplicar.Location = new System.Drawing.Point(310, 37);
            this.BTNaplicar.Name = "BTNaplicar";
            this.BTNaplicar.Size = new System.Drawing.Size(111, 33);
            this.BTNaplicar.TabIndex = 2;
            this.BTNaplicar.Text = "Aplicar";
            this.BTNaplicar.UseVisualStyleBackColor = true;
            this.BTNaplicar.Click += new System.EventHandler(this.BTNaplicar_Click);
            // 
            // TXTdescuento
            // 
            this.TXTdescuento.Location = new System.Drawing.Point(20, 54);
            this.TXTdescuento.Name = "TXTdescuento";
            this.TXTdescuento.Size = new System.Drawing.Size(100, 26);
            this.TXTdescuento.TabIndex = 1;
            // 
            // LBLdescuento
            // 
            this.LBLdescuento.AutoSize = true;
            this.LBLdescuento.Location = new System.Drawing.Point(29, 18);
            this.LBLdescuento.Name = "LBLdescuento";
            this.LBLdescuento.Size = new System.Drawing.Size(87, 20);
            this.LBLdescuento.TabIndex = 0;
            this.LBLdescuento.Text = "Descuento";
            // 
            // BTNlimpiar
            // 
            this.BTNlimpiar.Location = new System.Drawing.Point(659, 292);
            this.BTNlimpiar.Name = "BTNlimpiar";
            this.BTNlimpiar.Size = new System.Drawing.Size(99, 44);
            this.BTNlimpiar.TabIndex = 1;
            this.BTNlimpiar.Text = "Limpiar";
            this.BTNlimpiar.UseVisualStyleBackColor = true;
            this.BTNlimpiar.Click += new System.EventHandler(this.BTNlimpiar_Click);
            // 
            // BTNsalir
            // 
            this.BTNsalir.Location = new System.Drawing.Point(659, 342);
            this.BTNsalir.Name = "BTNsalir";
            this.BTNsalir.Size = new System.Drawing.Size(99, 41);
            this.BTNsalir.TabIndex = 2;
            this.BTNsalir.Text = "Salir";
            this.BTNsalir.UseVisualStyleBackColor = true;
            this.BTNsalir.Click += new System.EventHandler(this.BTNsalir_Click);
            // 
            // LBLtitulo
            // 
            this.LBLtitulo.AutoSize = true;
            this.LBLtitulo.Location = new System.Drawing.Point(290, 13);
            this.LBLtitulo.Name = "LBLtitulo";
            this.LBLtitulo.Size = new System.Drawing.Size(208, 20);
            this.LBLtitulo.TabIndex = 3;
            this.LBLtitulo.Text = "LABORATORIO EN CLASE";
            this.LBLtitulo.Click += new System.EventHandler(this.label1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LBLtitulo);
            this.Controls.Add(this.BTNsalir);
            this.Controls.Add(this.BTNlimpiar);
            this.Controls.Add(this.TAB);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.TAB.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl TAB;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label LBLtipodecambio;
        private System.Windows.Forms.Label LBLmarca;
        private System.Windows.Forms.Label LBLprecio;
        private System.Windows.Forms.Label LBLmodelo;
        private System.Windows.Forms.Button BTNguardarinfo;
        private System.Windows.Forms.TextBox TXTtipodecambio;
        private System.Windows.Forms.TextBox TXTmarca;
        private System.Windows.Forms.TextBox TXTprecio;
        private System.Windows.Forms.TextBox TXTmodelo;
        private System.Windows.Forms.Button BTNlimpiar;
        private System.Windows.Forms.Button BTNsalir;
        private System.Windows.Forms.TextBox TXTdatosautomovil;
        private System.Windows.Forms.Button BTNcambiardispo;
        private System.Windows.Forms.Button BTNaplicar;
        private System.Windows.Forms.TextBox TXTdescuento;
        private System.Windows.Forms.Label LBLdescuento;
        private System.Windows.Forms.Label LBLtitulo;
    }
}

