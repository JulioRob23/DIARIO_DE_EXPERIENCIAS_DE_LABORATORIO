﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Elija la opción que desea realizar");
        Console.WriteLine("");
        Console.WriteLine("1. Sumatoria");
        Console.WriteLine("2. Tablas de multiplicar");
        Console.WriteLine("3. Número perfecto");
        Console.WriteLine("");
        int opcion = Convert.ToInt32(Console.ReadLine());
        switch (opcion)
        {
            case 1:
                Console.Clear();
                Console.WriteLine("Ingrese un número");
                int num = Convert.ToInt32(Console.ReadLine());
                int suma = 0;
                do
                {
                    suma = suma + num;
                    num--;
                    
                }
                while (num>0);
                Console.WriteLine("La sumatoria es: " + suma);
                break;
            case 2:
                Console.Clear();
                Console.WriteLine("Ingrese el número de tabla que desea desplegar del 1 al 10 ");
                int n = Convert.ToInt32(Console.ReadLine());
                
                if (n>0 & n <= 10) 
                {

                    for (int i = 1; i <= 10; i++)
                    {
                        Console.WriteLine(n + "*" + i + "= " + n * i);
                    }
                }
                else
                {
                    Console.WriteLine("Debe ingresar un número dentro del rango");
                }
                
                break;
            case 3:
                Console.Clear();
                Console.WriteLine("Ingrese un número mayor que 0");
                int numero;
                bool validar = int.TryParse(Console.ReadLine(), out numero);
                int sumafactor = 0;
                if (validar = true)
                {
                    if (numero > 0)
                    {
                        for (int a = 1; a < numero; a++)
                        {
                            if (numero % a == 0)
                            {
                                sumafactor = a + sumafactor;
                            }
                            
                        }
                        if (sumafactor == numero)
                        {
                            Console.WriteLine("Es un número perfecto");
                        }
                        else
                        {
                            Console.WriteLine("No es número perfecto");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Error: debe ingresar un número mayor a 0");
                    }
                }
                else
                {
                    Console.WriteLine("Error: Usted ingreso una letra");
                }
                break;
            default:
                break;
        }
    }
}