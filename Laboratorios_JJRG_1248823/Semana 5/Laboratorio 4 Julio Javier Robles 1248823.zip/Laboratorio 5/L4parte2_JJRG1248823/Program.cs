﻿internal class Program
{
    private static void Main(string[] args)
    {
        // ejercicio 3
        Console.WriteLine("Ingrese 3 núemeros:");
        double a = Convert.ToDouble(Console.ReadLine());
        double b = Convert.ToDouble(Console.ReadLine());
        double c = Convert.ToDouble(Console.ReadLine());
        double r1 = a * b + c;
        double r2 = a * (b + c);
        double r3 = a / (b + c);
        double a1 = 3 * a;
        double b2 = 2 * b;
        double c1 = Math.Pow(c, 2);
        double r4 = (a1 + b2) / c1;

        Console.WriteLine("Expresión 1: a*b+c");
        Console.WriteLine(r1);
        Console.WriteLine("Expresión 1: a*(b+c)");
        Console.WriteLine(r2);
        Console.WriteLine("Expresión 1: a/b+c");
        Console.WriteLine(r3);
        Console.WriteLine("Expresión 1: 3a+2b/c^2");
        Console.WriteLine(r4);

        Console.WriteLine("");
        Console.WriteLine("Presione una tecla para continuar");
        Console.WriteLine("");

        Console.ReadKey();
        // ejercicio 4 
        double b3 = b * -1;
        double b4 = Math.Pow(b, 2);
        double d = (-4 * a);
        double u = d * c;
        double a3 = 2 * a;
        double s = b4 + u;
        double discriminante = Math.Sqrt(s);
        double raiz1 = (b3 + discriminante) / a3;
        double raiz2 = (b3 - discriminante) / a3;

        if (s >= 0 && a!=0)
        {
            Console.WriteLine("x1 = " + raiz1);
            Console.WriteLine("x2 = " + raiz2);
        }
        else
        {
            Console.WriteLine("La ecuación no tiene soluciones reales");
        }

        Console.ReadKey();
        
    }
}