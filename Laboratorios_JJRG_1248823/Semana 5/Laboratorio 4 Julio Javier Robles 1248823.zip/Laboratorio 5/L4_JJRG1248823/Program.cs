﻿internal class Program
{
    private static void Main(string[] args)
    {
// ejercicio 1 
        Console.WriteLine("Ejercicio 1: operaciones aritméticas");
        Console.WriteLine("Ingrese 2 números");
        double n1 = Convert.ToDouble(Console.ReadLine());
        double n2 = Convert.ToDouble(Console.ReadLine());
        double s = n1 + n2;
        double r = n1 - n2;
        double m = n1 * n2;
        double d = n1 / n2;
        double md = n1 % n2;

        int ni1 = Convert.ToInt32(n1);
        int ni2 = Convert.ToInt32(n2); 
        int d2 = ni1 / ni2;

        Console.WriteLine("Resultados: ");
        Console.WriteLine(n1 + "+" + n2 + "=" + s);
        Console.WriteLine(n1 + "-" + n2 + "=" + r);
        Console.WriteLine(n1 + "*" + n2 + "=" + m);
        Console.WriteLine(n1 + "/" + n2 + "=" + d);
        Console.WriteLine(n1 + " div " + n2 + "=" + d2);
        Console.WriteLine(n1 + " % " + n2 + "=" + md);
        Console.WriteLine("");
        Console.WriteLine("Presione una tecla para continuar");
        Console.ReadKey();

        // ejercicio 2 
        Console.WriteLine("");
        Console.WriteLine("Ejercicio 2: operaciones booleanas");
        Console.WriteLine("");
        if
            (n1 > n2)
            Console.WriteLine(n1 + ">" + n2);
        else if
            (n1 < n2)
            Console.WriteLine(n2 + ">" + n1);
            else
                Console.WriteLine(n1 + "=" + n2);

        Console.ReadKey();
    }
}