﻿using System;

class Circulo
{
    private double radio;
    private double pi = System.Math.PI;

    private double ObtenerPerimetro()
    {
        double perimetro = 2 * radio * pi;
        return perimetro;
    }
    private double ObtenerArea()
    {
        double area = pi*Math.Pow(radio,2);
        return area;
    }
    private double ObtenerVolumen()
    {
        double volumen = (4*pi*Math.Pow(radio,3))/3;
        return volumen;
    }
    public void CalcularGeometria(ref double UnPerimetro, ref double UnArea,  ref double UnVolumen)
    {
        UnPerimetro = ObtenerPerimetro();
        UnArea = ObtenerArea();
        UnVolumen = ObtenerVolumen();
    }
    public void MostrarCalculos()
    {
        Console.WriteLine("Perimetro: " + ObtenerPerimetro());
        Console.WriteLine("Area: " + ObtenerArea());
        Console.WriteLine("Volumen: " + ObtenerVolumen());
    }
    public Circulo (double rad)
    {
        radio = rad;
    }

    public static void Main()
    {
        Console.WriteLine("Igrese el valor del radio");
        double r = Convert.ToInt32(Console.ReadLine());

        Circulo c = new Circulo(r);
        c.MostrarCalculos();
    }
}