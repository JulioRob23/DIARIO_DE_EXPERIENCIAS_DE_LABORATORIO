﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L8_forms_JJRG_1248823
{
    public partial class LABORATORIO_8 : Form
    {
        public LABORATORIO_8()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void LABORATORIO_8_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void CMBseleccion_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(CMBseleccion.SelectedIndex)
            {
                case 0:
                    MessageBox.Show("Hola super humano vamos a seleccionar la pestaña de sumatoria");
                    Tabdatos.SelectedTab = tabPage1;
                    break;
                case 1:
                    MessageBox.Show("Mostraremos las tablas de multiplicar");
                    Tabdatos.SelectedTab = tabPage2;
                    break;
                case 2:
                    MessageBox.Show("Encontraremos el número perfecto");
                    Tabdatos.SelectedTab = tabPage3;
                    break;
            }
        }

        private void TXTnumero_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void BTNseleccion_Click(object sender, EventArgs e)
        {
            
            
            int num = Convert.ToInt32(TXTnumero.Text);
            int suma = 0;
            do
            {
                suma = suma + num;
                num--;

            }
            while (num > 0);
            LBLrestotal.Text = "" + suma;

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(TXTnum2.Text);

            if (n > 0 & n <= 10)
            {

                for (int i = 1; i <= 10; i++)
                {
                    LBLtablas.Text += "\n"+ n + "*" + i + "= " + n * i;
                }
            }
            else
            {
                LBLtablas.Text = "Debe ingresar un número dentro del rango";
            }
        }

        private void BTNresperfecto_Click(object sender, EventArgs e)
        {
            int numero; 
            int sumafactor = 0;
            bool validar = int.TryParse(TBTnumper.Text, out numero);

            if (validar = true)
            {
                if (numero > 0)
                {
                    for (int a = 1; a < numero; a++)
                    {
                        if (numero % a == 0)
                        {
                            sumafactor = a + sumafactor;
                        }

                    }
                    if (sumafactor == numero)
                    {
                        LBLresperfect.Text = "Es un número perfecto";
                    }
                    else
                    {
                        LBLresperfect.Text = "No es número perfecto";
                    }
                }
                else
                {
                    LBLresperfect.Text = "Error: debe ingresar un número mayor a 0";
                }
            }
            else
            {
                Console.WriteLine("Error: Usted ingreso una letra");
            }
        }
    }
}
