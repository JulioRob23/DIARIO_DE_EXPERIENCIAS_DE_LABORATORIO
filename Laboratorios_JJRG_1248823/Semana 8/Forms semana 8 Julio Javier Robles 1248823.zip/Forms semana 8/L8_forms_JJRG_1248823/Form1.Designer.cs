﻿namespace L8_forms_JJRG_1248823
{
    partial class LABORATORIO_8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Titulo = new System.Windows.Forms.Label();
            this.Seleccion = new System.Windows.Forms.GroupBox();
            this.CMBseleccion = new System.Windows.Forms.ComboBox();
            this.BTNseleccion = new System.Windows.Forms.Button();
            this.Tabdatos = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.LBLrestotal = new System.Windows.Forms.Label();
            this.TXTnumero = new System.Windows.Forms.TextBox();
            this.LBLresultado = new System.Windows.Forms.Label();
            this.LBLingrese = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.LBLrestotal2 = new System.Windows.Forms.Label();
            this.TXTnum2 = new System.Windows.Forms.TextBox();
            this.LBLresultado2 = new System.Windows.Forms.Label();
            this.LBLtablas = new System.Windows.Forms.Label();
            this.BTdesplegartablas = new System.Windows.Forms.Button();
            this.LBLingresep = new System.Windows.Forms.Label();
            this.TBTnumper = new System.Windows.Forms.TextBox();
            this.LBLresper = new System.Windows.Forms.Label();
            this.LBLresperfect = new System.Windows.Forms.Label();
            this.BTNresperfecto = new System.Windows.Forms.Button();
            this.Seleccion.SuspendLayout();
            this.Tabdatos.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // Titulo
            // 
            this.Titulo.AutoSize = true;
            this.Titulo.BackColor = System.Drawing.Color.Lime;
            this.Titulo.Font = new System.Drawing.Font("Jokerman", 11F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Titulo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Titulo.Location = new System.Drawing.Point(260, 33);
            this.Titulo.Name = "Titulo";
            this.Titulo.Size = new System.Drawing.Size(202, 33);
            this.Titulo.TabIndex = 0;
            this.Titulo.Text = "LABORATORIO 8";
            this.Titulo.Click += new System.EventHandler(this.label1_Click);
            // 
            // Seleccion
            // 
            this.Seleccion.Controls.Add(this.CMBseleccion);
            this.Seleccion.Location = new System.Drawing.Point(12, 97);
            this.Seleccion.Name = "Seleccion";
            this.Seleccion.Size = new System.Drawing.Size(199, 100);
            this.Seleccion.TabIndex = 1;
            this.Seleccion.TabStop = false;
            this.Seleccion.Text = "Seleccionar: ";
            // 
            // CMBseleccion
            // 
            this.CMBseleccion.FormattingEnabled = true;
            this.CMBseleccion.Items.AddRange(new object[] {
            "SUMATORIA",
            "TABLAS",
            "NÚMERO PERFECTO"});
            this.CMBseleccion.Location = new System.Drawing.Point(50, 56);
            this.CMBseleccion.Name = "CMBseleccion";
            this.CMBseleccion.Size = new System.Drawing.Size(121, 28);
            this.CMBseleccion.TabIndex = 0;
            this.CMBseleccion.SelectedIndexChanged += new System.EventHandler(this.CMBseleccion_SelectedIndexChanged);
            // 
            // BTNseleccion
            // 
            this.BTNseleccion.Location = new System.Drawing.Point(14, 184);
            this.BTNseleccion.Name = "BTNseleccion";
            this.BTNseleccion.Size = new System.Drawing.Size(148, 30);
            this.BTNseleccion.TabIndex = 2;
            this.BTNseleccion.Text = "Seleccionar";
            this.BTNseleccion.UseVisualStyleBackColor = true;
            this.BTNseleccion.Click += new System.EventHandler(this.BTNseleccion_Click);
            // 
            // Tabdatos
            // 
            this.Tabdatos.Controls.Add(this.tabPage1);
            this.Tabdatos.Controls.Add(this.tabPage2);
            this.Tabdatos.Controls.Add(this.tabPage3);
            this.Tabdatos.Location = new System.Drawing.Point(266, 84);
            this.Tabdatos.Name = "Tabdatos";
            this.Tabdatos.SelectedIndex = 0;
            this.Tabdatos.Size = new System.Drawing.Size(480, 440);
            this.Tabdatos.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.LBLrestotal);
            this.tabPage1.Controls.Add(this.BTNseleccion);
            this.tabPage1.Controls.Add(this.TXTnumero);
            this.tabPage1.Controls.Add(this.LBLresultado);
            this.tabPage1.Controls.Add(this.LBLingrese);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(452, 229);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Sumatoria";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // LBLrestotal
            // 
            this.LBLrestotal.AutoSize = true;
            this.LBLrestotal.Location = new System.Drawing.Point(189, 101);
            this.LBLrestotal.Name = "LBLrestotal";
            this.LBLrestotal.Size = new System.Drawing.Size(0, 20);
            this.LBLrestotal.TabIndex = 3;
            // 
            // TXTnumero
            // 
            this.TXTnumero.Location = new System.Drawing.Point(193, 42);
            this.TXTnumero.Name = "TXTnumero";
            this.TXTnumero.Size = new System.Drawing.Size(100, 26);
            this.TXTnumero.TabIndex = 2;
            this.TXTnumero.TextChanged += new System.EventHandler(this.TXTnumero_TextChanged);
            // 
            // LBLresultado
            // 
            this.LBLresultado.AutoSize = true;
            this.LBLresultado.Location = new System.Drawing.Point(35, 101);
            this.LBLresultado.Name = "LBLresultado";
            this.LBLresultado.Size = new System.Drawing.Size(82, 20);
            this.LBLresultado.TabIndex = 1;
            this.LBLresultado.Text = "Resultado";
            // 
            // LBLingrese
            // 
            this.LBLingrese.AutoSize = true;
            this.LBLingrese.Location = new System.Drawing.Point(26, 48);
            this.LBLingrese.Name = "LBLingrese";
            this.LBLingrese.Size = new System.Drawing.Size(136, 20);
            this.LBLingrese.TabIndex = 0;
            this.LBLingrese.Text = "Ingrese número N";
            this.LBLingrese.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.BTdesplegartablas);
            this.tabPage2.Controls.Add(this.LBLtablas);
            this.tabPage2.Controls.Add(this.LBLresultado2);
            this.tabPage2.Controls.Add(this.TXTnum2);
            this.tabPage2.Controls.Add(this.LBLrestotal2);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(472, 407);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Tablas";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.BTNresperfecto);
            this.tabPage3.Controls.Add(this.LBLresperfect);
            this.tabPage3.Controls.Add(this.LBLresper);
            this.tabPage3.Controls.Add(this.TBTnumper);
            this.tabPage3.Controls.Add(this.LBLingresep);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(452, 229);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Número Perfecto";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // LBLrestotal2
            // 
            this.LBLrestotal2.AutoSize = true;
            this.LBLrestotal2.Location = new System.Drawing.Point(42, 21);
            this.LBLrestotal2.Name = "LBLrestotal2";
            this.LBLrestotal2.Size = new System.Drawing.Size(347, 20);
            this.LBLrestotal2.TabIndex = 0;
            this.LBLrestotal2.Text = "Ingrese la tabla que desea desplegar del 1 al 10";
            // 
            // TXTnum2
            // 
            this.TXTnum2.Location = new System.Drawing.Point(158, 58);
            this.TXTnum2.Name = "TXTnum2";
            this.TXTnum2.Size = new System.Drawing.Size(100, 26);
            this.TXTnum2.TabIndex = 1;
            // 
            // LBLresultado2
            // 
            this.LBLresultado2.AutoSize = true;
            this.LBLresultado2.Location = new System.Drawing.Point(16, 86);
            this.LBLresultado2.Name = "LBLresultado2";
            this.LBLresultado2.Size = new System.Drawing.Size(64, 20);
            this.LBLresultado2.TabIndex = 2;
            this.LBLresultado2.Text = "Tablas: ";
            // 
            // LBLtablas
            // 
            this.LBLtablas.AutoSize = true;
            this.LBLtablas.Location = new System.Drawing.Point(111, 115);
            this.LBLtablas.Name = "LBLtablas";
            this.LBLtablas.Size = new System.Drawing.Size(0, 20);
            this.LBLtablas.TabIndex = 3;
            // 
            // BTdesplegartablas
            // 
            this.BTdesplegartablas.Location = new System.Drawing.Point(329, 188);
            this.BTdesplegartablas.Name = "BTdesplegartablas";
            this.BTdesplegartablas.Size = new System.Drawing.Size(120, 35);
            this.BTdesplegartablas.TabIndex = 4;
            this.BTdesplegartablas.Text = "Desplegar";
            this.BTdesplegartablas.UseVisualStyleBackColor = true;
            this.BTdesplegartablas.Click += new System.EventHandler(this.button1_Click);
            // 
            // LBLingresep
            // 
            this.LBLingresep.AutoSize = true;
            this.LBLingresep.Location = new System.Drawing.Point(37, 16);
            this.LBLingresep.Name = "LBLingresep";
            this.LBLingresep.Size = new System.Drawing.Size(216, 20);
            this.LBLingresep.TabIndex = 0;
            this.LBLingresep.Text = "Ingrese un número mayor a 0";
            // 
            // TBTnumper
            // 
            this.TBTnumper.Location = new System.Drawing.Point(168, 58);
            this.TBTnumper.Name = "TBTnumper";
            this.TBTnumper.Size = new System.Drawing.Size(100, 26);
            this.TBTnumper.TabIndex = 1;
            // 
            // LBLresper
            // 
            this.LBLresper.AutoSize = true;
            this.LBLresper.Location = new System.Drawing.Point(41, 135);
            this.LBLresper.Name = "LBLresper";
            this.LBLresper.Size = new System.Drawing.Size(87, 20);
            this.LBLresper.TabIndex = 2;
            this.LBLresper.Text = "Respuesta";
            // 
            // LBLresperfect
            // 
            this.LBLresperfect.AutoSize = true;
            this.LBLresperfect.Location = new System.Drawing.Point(185, 145);
            this.LBLresperfect.Name = "LBLresperfect";
            this.LBLresperfect.Size = new System.Drawing.Size(0, 20);
            this.LBLresperfect.TabIndex = 3;
            // 
            // BTNresperfecto
            // 
            this.BTNresperfecto.Location = new System.Drawing.Point(351, 166);
            this.BTNresperfecto.Name = "BTNresperfecto";
            this.BTNresperfecto.Size = new System.Drawing.Size(75, 43);
            this.BTNresperfecto.TabIndex = 4;
            this.BTNresperfecto.Text = "Calcular";
            this.BTNresperfecto.UseVisualStyleBackColor = true;
            this.BTNresperfecto.Click += new System.EventHandler(this.BTNresperfecto_Click);
            // 
            // LABORATORIO_8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(827, 623);
            this.Controls.Add(this.Tabdatos);
            this.Controls.Add(this.Seleccion);
            this.Controls.Add(this.Titulo);
            this.Name = "LABORATORIO_8";
            this.Text = "LABORATORIO 8";
            this.Load += new System.EventHandler(this.LABORATORIO_8_Load);
            this.Seleccion.ResumeLayout(false);
            this.Tabdatos.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Titulo;
        private System.Windows.Forms.GroupBox Seleccion;
        private System.Windows.Forms.ComboBox CMBseleccion;
        private System.Windows.Forms.Button BTNseleccion;
        private System.Windows.Forms.TabControl Tabdatos;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label LBLingrese;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label LBLresultado;
        private System.Windows.Forms.Label LBLrestotal;
        private System.Windows.Forms.TextBox TXTnumero;
        private System.Windows.Forms.TextBox TXTnum2;
        private System.Windows.Forms.Label LBLrestotal2;
        private System.Windows.Forms.Label LBLtablas;
        private System.Windows.Forms.Label LBLresultado2;
        private System.Windows.Forms.Button BTdesplegartablas;
        private System.Windows.Forms.Button BTNresperfecto;
        private System.Windows.Forms.Label LBLresperfect;
        private System.Windows.Forms.Label LBLresper;
        private System.Windows.Forms.TextBox TBTnumper;
        private System.Windows.Forms.Label LBLingresep;
    }
}

